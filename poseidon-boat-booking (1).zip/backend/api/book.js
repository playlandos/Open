const sgMail = require('@sendgrid/mail');
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

module.exports = async (req, res) => {
  const booking = req.body;
  // Save to DB logic would go here
  const msg = {
    to: booking.email,
    from: 'bookings@poseidonboats.gr',
    subject: 'Booking Confirmation - Poseidon Rent A Boat',
    text: `Hi ${booking.name},\n\nThank you for your booking of ${booking.boatName} on ${booking.date}.\nTotal: €${booking.total}.\n\nPlease transfer this amount to:\nIBAN: ${process.env.BANK_IBAN}\nReference: ${booking.name}\n\nLooking forward to seeing you!\n\n- Poseidon Team`
  };
  await sgMail.send(msg);
  res.status(200).json({ success: true });
};
